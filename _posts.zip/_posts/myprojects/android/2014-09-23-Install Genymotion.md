---
layout: post
category : Android 
tagline: "Android開發"
tags : [Installation Guide,App,Android,Genymotion]
title: "安裝Genymotion "

---


### 參考文章
[安裝Genymotion
](http://www.max-everyday.com/2013/07/genymotion-android.html
)

[安裝Android Studio以及Genymotion
](http://tleyden.github.io/blog/2013/11/22/android-studio-plus-genymotion-emulator/
)