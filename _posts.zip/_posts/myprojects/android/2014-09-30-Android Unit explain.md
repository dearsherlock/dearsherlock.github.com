---
layout: post
category : Android 
tagline: "Android開發教學"
tags : [Android Develop,教學文章,單位]
title: "Android 尺寸單位解釋"

---

### 介紹Android的尺寸單位說明

- px – 螢幕畫素。
- dp – 每英吋畫面，160dp為一英吋。
- sp – 和dp一樣，不過會根據裝置設定的字型大小自動調整。
- in – 英吋。
- mm – 公厘。